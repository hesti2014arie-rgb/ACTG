package com.actg.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/** Swipe dari (x1,y1) ke (x2,y2) selama [ms] milidetik. */
data class Swipe(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val ms: Long)

/** Joystick sentuh: jari turun di (cx,cy), digeser ke (tx,ty), lalu DITAHAN di sana. */
data class Move(val cx: Float, val cy: Float, val tx: Float, val ty: Float)

/**
 * "Jari" ACTG: menyuntikkan sentuhan ke layar.
 *
 * Joystick ditahan terus-menerus memakai stroke bersambung (willContinue + continueStroke):
 * jari tetap menempel di layar sampai AI memberi perintah STOP (atau batas aman [MAX_HOLD_MS] habis).
 * Tap/swipe lain dari AI digabung ke gesture yang sama, jadi tidak memutus joystick.
 *
 * Harus diaktifkan manual oleh pengguna di Pengaturan > Aksesibilitas.
 */
class ControlService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ControlService? = null

        private const val FRAME_MS = 300L       // panjang tiap potongan tahan joystick
        private const val MAX_HOLD_MS = 8000L   // pengaman: lepas otomatis jika AI berhenti memberi perintah
    }

    private val main = Handler(Looper.getMainLooper())

    // Semua state di bawah hanya disentuh dari main thread.
    private var stick: StrokeDescription? = null // stroke joystick yang sedang menempel (willContinue = true)
    private var fingerX = 0f
    private var fingerY = 0f
    private var target: Move? = null
    private var release = false
    private var pumping = false
    private var lastMoveAt = 0L
    private val tapQueue = ArrayList<Triple<Float, Float, Long>>()
    private val swipeQueue = ArrayList<Swipe>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        main.removeCallbacksAndMessages(null)
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        main.post { resetState() }
    }

    // ---------- API untuk CaptureService (aman dipanggil dari thread mana pun) ----------

    /**
     * @param move  arah joystick baru (null = jangan ubah joystick)
     * @param stopMove true = lepas joystick
     */
    fun perform(
        move: Move?,
        stopMove: Boolean,
        taps: List<Triple<Float, Float, Long>>,
        swipes: List<Swipe>,
    ) {
        main.post {
            if (move != null) {
                target = move
                release = false
                lastMoveAt = SystemClock.elapsedRealtime()
            } else if (stopMove) {
                release = true
            }
            tapQueue.addAll(taps)
            swipeQueue.addAll(swipes)
            pump()
        }
    }

    /** Lepas joystick (dipanggil saat AI dijeda/error/ditutup). */
    fun releaseMove() {
        main.post {
            release = true
            pump()
        }
    }

    // ---------- mesin gesture ----------

    private fun resetState() {
        stick = null
        target = null
        release = false
        pumping = false
        tapQueue.clear()
        swipeQueue.clear()
    }

    private fun pump() {
        if (pumping) return
        if (stick == null && target == null && tapQueue.isEmpty() && swipeQueue.isEmpty()) return
        dispatchFrame()
    }

    private fun dispatchFrame() {
        if (target != null && SystemClock.elapsedRealtime() - lastMoveAt > MAX_HOLD_MS) release = true

        val b = GestureDescription.Builder()
        var any = false

        // 1) joystick
        val t = target
        if (release) {
            val s = stick
            if (s != null) {
                val p = Path().apply { moveTo(fingerX, fingerY) }
                b.addStroke(s.continueStroke(p, 0, 50, false)) // akhiri: angkat jari
                any = true
            }
            stick = null
            target = null
            release = false
        } else if (t != null) {
            val s = stick
            val ns: StrokeDescription
            if (s == null) {
                val p = Path().apply {
                    moveTo(t.cx, t.cy)
                    lineTo(t.tx, t.ty)
                }
                ns = StrokeDescription(p, 0, 150, true)
            } else {
                val p = Path().apply {
                    moveTo(fingerX, fingerY)
                    if (fingerX != t.tx || fingerY != t.ty) lineTo(t.tx, t.ty)
                }
                ns = s.continueStroke(p, 0, FRAME_MS, true)
            }
            fingerX = t.tx
            fingerY = t.ty
            stick = ns
            b.addStroke(ns)
            any = true
        }

        // 2) tap & swipe dari AI (digabung agar tidak memutus joystick)
        val taps = tapQueue.take(5)
        val swipes = swipeQueue.take(3)
        tapQueue.clear()
        swipeQueue.clear()
        taps.forEach { (x, y, hold) ->
            val path = Path().apply { moveTo(x, y) }
            b.addStroke(StrokeDescription(path, 0, hold.coerceIn(30L, 3000L)))
            any = true
        }
        swipes.forEach { s ->
            val path = Path().apply {
                moveTo(s.x1, s.y1)
                lineTo(s.x2, s.y2)
            }
            b.addStroke(StrokeDescription(path, 0, s.ms.coerceIn(50L, 3000L)))
            any = true
        }

        if (!any) return

        pumping = true
        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                pumping = false
                pump()
            }

            override fun onCancelled(gestureDescription: GestureDescription) {
                // Jari sudah terputus (mis. pengguna menyentuh layar). Mulai ulang dari awal jika masih perlu.
                pumping = false
                stick = null
                main.postDelayed({ pump() }, 80)
            }
        }, main)
        if (!ok) {
            pumping = false
            stick = null
        }
    }
}
