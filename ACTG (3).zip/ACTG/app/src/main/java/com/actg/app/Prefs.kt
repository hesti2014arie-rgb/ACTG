package com.actg.app

import android.content.Context
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject

/** Satu tombol virtual yang bisa "ditekan" AI. */
data class GameButton(
    val name: String,
    val hint: String,
    val holdMs: Long,
    /** "" = tap biasa. "UP/DOWN/LEFT/RIGHT" = tombol arah: drag joystick sentuh game ke arah itu. */
    val dir: String = "",
)

const val JOYSTICK = "JOYSTICK"

/** Contoh tujuan untuk game survival Roblox dengan killer. */
const val PRESET_SURVIVAL =
    "Ini game survival Roblox: kamu survivor, ada KILLER yang memburu. Prioritas:\n" +
        "1) Tiap giliran, cari killer di layar (karakter musuh yang besar/aneh, nama merah, HP turun, layar memerah). " +
        "Kalau killer terlihat atau dekat: LARI menjauh. Putar kamera supaya killer ada di belakang, lalu MAJU dan SPRINT. " +
        "Jangan menghadap atau mendekati killer.\n" +
        "2) Kalau aman: kerjakan objektif yang tertulis di layar (mis. generator) dan jelajahi lorong.\n" +
        "3) Kalau menabrak tembok atau layar tidak berubah: putar kamera dulu, jangan terus MAJU."

/** Tebak arah dari nama tombol lama (migrasi tombol yang disimpan sebelum fitur joystick). */
fun guessDir(name: String): String = when (name.uppercase()) {
    "MAJU", "FORWARD", "UP", "ATAS" -> "UP"
    "BELAKANG", "MUNDUR", "BACK", "DOWN", "BAWAH" -> "DOWN"
    "LEFT", "KIRI" -> "LEFT"
    "RIGHT", "KANAN" -> "RIGHT"
    else -> ""
}

fun defaultModel(provider: String) = when (provider) {
    "openai" -> "gpt-4o-mini"
    "gemini" -> "gemini-3.5-flash-lite"
    else -> "claude-haiku-5-5"
}

fun isLandscape(ctx: Context): Boolean {
    val b = ctx.getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
    return b.width() > b.height()
}

class Prefs(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("actg", Context.MODE_PRIVATE)

    /** "anthropic" | "openai" | "gemini" */
    var provider: String
        get() = sp.getString("provider", "anthropic") ?: "anthropic"
        set(v) = sp.edit().putString("provider", v).apply()

    /** API key disimpan per penyedia. */
    var apiKey: String
        get() = sp.getString("api_key_$provider", "") ?: ""
        set(v) = sp.edit().putString("api_key_$provider", v.trim()).apply()

    var model: String
        get() {
            val saved = sp.getString("model_$provider", null) ?: ""
            // gemini-2.0-* sudah dimatikan Google (Juni 2026) -> pakai default baru
            return if (saved.isBlank() || saved.startsWith("gemini-2.0")) defaultModel(provider) else saved
        }
        set(v) = sp.edit().putString("model_$provider", v.trim()).apply()

    var goal: String
        get() = sp.getString(
            "goal",
            "Mainkan game ini sebaik mungkin: hindari bahaya, kumpulkan poin, dan bertahan selama mungkin."
        ) ?: ""
        set(v) = sp.edit().putString("goal", v.trim()).apply()

    var intervalMs: Long
        get() = sp.getLong("interval_ms", 500L)
        set(v) = sp.edit().putLong("interval_ms", v.coerceIn(500L, 30000L)).apply()

    fun buttons(): List<GameButton> {
        val raw = sp.getString("buttons", null) ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                val name = o.getString("name")
                val dir = if (o.has("dir")) o.optString("dir") else guessDir(name)
                val hold = o.optLong("hold", 150L).let { if (dir.isNotEmpty() && it < 400L) 600L else it }
                GameButton(name, o.optString("hint"), hold, dir)
            }
        } catch (e: Exception) {
            defaults()
        }
    }

    fun saveButtons(list: List<GameButton>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("name", it.name).put("hint", it.hint)
                    .put("hold", it.holdMs).put("dir", it.dir)
            )
        }
        sp.edit().putString("buttons", arr.toString()).apply()
    }

    private fun defaults() = listOf(
        GameButton("MAJU", "Jalan maju", 600, "UP"),
        GameButton("BELAKANG", "Jalan mundur", 600, "DOWN"),
        GameButton("LEFT", "Jalan ke kiri", 600, "LEFT"),
        GameButton("RIGHT", "Jalan ke kanan", 600, "RIGHT"),
        GameButton("JUMP", "Lompat", 120),
        GameButton("ATTACK", "Serang", 120),
    )

    /** Posisi pusat tombol (piksel layar). Disimpan terpisah untuk portrait & landscape. */
    fun position(name: String, landscape: Boolean): Pair<Int, Int> {
        val saved = sp.getString(key(name, landscape), null)
        if (saved != null) {
            val p = saved.split(",")
            if (p.size == 2) return p[0].toInt() to p[1].toInt()
        }
        val b = ctx.getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        if (name == JOYSTICK) return (b.width() * 0.15).toInt() to (b.height() * 0.62).toInt()
        val idx = buttons().filter { it.dir.isEmpty() }.indexOfFirst { it.name == name }.coerceAtLeast(0)
        val x = (b.width() * (0.12 + 0.14 * idx)).toInt().coerceAtMost(b.width() - 60)
        val y = (b.height() * 0.8).toInt()
        return x to y
    }

    fun setPosition(name: String, landscape: Boolean, x: Int, y: Int) {
        sp.edit().putString(key(name, landscape), "$x,$y").apply()
    }

    private fun key(name: String, landscape: Boolean) = "pos_${if (landscape) "l" else "p"}_$name"
}
