package com.actg.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var statusView: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var etKey: EditText
    private lateinit var etModel: EditText
    private lateinit var etGoal: EditText
    private lateinit var etInterval: EditText

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .putExtra(CaptureService.EXTRA_CODE, r.resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                toast("ACTG aktif. Buka game-nya, atur tombol, lalu tekan ▶ di panel.")
            } else {
                toast("Izin tangkap layar ditolak.")
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContentView(buildUi())
        refreshButtons()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onPause() {
        super.onPause()
        saveFields()
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }

        fun title(t: String, size: Float = 16f) = TextView(this).apply {
            text = t
            textSize = size
            setPadding(0, dp(14), 0, dp(4))
        }

        fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT) =
            EditText(this).apply {
                this.hint = hint
                setText(value)
                inputType = type
            }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { onClick() }
        }

        root.addView(title("ACTG — AI Control The Game", 22f))
        statusView = TextView(this)
        root.addView(statusView)

        root.addView(title("1. Izin"))
        root.addView(button("Izinkan tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("Aktifkan layanan Aksesibilitas ACTG") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(title("2. AI"))
        etKey = field(
            "API key", prefs.apiKey,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        )
        etModel = field("Model", prefs.model)
        etGoal = field("Tujuan AI di game", prefs.goal, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        etInterval = field("Jeda antar keputusan (ms)", prefs.intervalMs.toString(), InputType.TYPE_CLASS_NUMBER)
        val providers = listOf("anthropic" to "Claude", "openai" to "OpenAI", "gemini" to "Gemini")
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        providers.forEachIndexed { i, (_, label) ->
            group.addView(RadioButton(this).apply {
                text = label
                this.id = 1000 + i
            })
        }
        group.check(1000 + providers.indexOfFirst { it.first == prefs.provider }.coerceAtLeast(0))
        group.setOnCheckedChangeListener { _, checked ->
            saveFields() // simpan key & model milik penyedia lama
            prefs.provider = providers[checked - 1000].first
            etKey.setText(prefs.apiKey)
            etModel.setText(prefs.model)
        }
        root.addView(group)
        listOf(etKey, etModel, etGoal, etInterval).forEach { root.addView(it) }

        root.addView(title("3. Tombol virtual"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        root.addView(button("+ Tambah tombol") { addDialog() })

        root.addView(title("4. Jalankan"))
        root.addView(button("Mulai ACTG") { start() })
        root.addView(button("Hentikan ACTG") {
            stopService(Intent(this, CaptureService::class.java))
            refreshStatus()
        })

        return ScrollView(this).apply { addView(root) }
    }

    private fun refreshButtons() {
        listBox.removeAllViews()
        prefs.buttons().forEach { b ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(TextView(this).apply {
                text = "${b.name} — ${b.hint} (${b.holdMs} ms)" +
                    if (b.dir.isNotEmpty()) " [joystick ${b.dir}]" else ""
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(Button(this).apply {
                text = "Hapus"
                setOnClickListener {
                    prefs.saveButtons(prefs.buttons().filter { it.name != b.name })
                    refreshButtons()
                }
            })
            listBox.addView(row)
        }
    }

    private fun addDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val n = EditText(this).apply { hint = "Nama (mis. JUMP)"; setSingleLine() }
        val h = EditText(this).apply { hint = "Fungsi (mis. Lompat)"; setSingleLine() }
        val d = EditText(this).apply {
            hint = "Lama tekan (ms)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("150")
        }
        val kinds = listOf("Tap biasa", "Joystick ATAS (maju)", "Joystick BAWAH (mundur)", "Joystick KIRI", "Joystick KANAN")
        val dirs = listOf("", "UP", "DOWN", "LEFT", "RIGHT")
        val spin = android.widget.Spinner(this).apply {
            adapter = android.widget.ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item, kinds
            )
        }
        listOf(n, h, d, spin).forEach { box.addView(it) }

        AlertDialog.Builder(this)
            .setTitle("Tambah tombol")
            .setView(box)
            .setPositiveButton("Tambah") { _, _ ->
                val name = n.text.toString().trim().uppercase().replace(" ", "_")
                val current = prefs.buttons()
                if (name.isEmpty() || current.any { it.name == name }) {
                    toast("Nama kosong atau sudah dipakai")
                } else {
                    val hold = d.text.toString().toLongOrNull() ?: 150L
                    val dir = dirs[spin.selectedItemPosition]
                    prefs.saveButtons(current + GameButton(name, h.text.toString().trim(), hold, dir))
                    refreshButtons()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- logika ----------

    private fun saveFields() {
        if (!::etKey.isInitialized) return
        prefs.apiKey = etKey.text.toString()
        prefs.model = etModel.text.toString().ifBlank { defaultModel(prefs.provider) }
        prefs.goal = etGoal.text.toString()
        prefs.intervalMs = etInterval.text.toString().toLongOrNull() ?: 1500L
    }

    private fun refreshStatus() {
        val overlay = if (Settings.canDrawOverlays(this)) "✅" else "❌"
        val acc = if (ControlService.instance != null) "✅" else "❌"
        val svc = if (CaptureService.running) "✅ berjalan" else "⏹ berhenti"
        statusView.text = "Overlay: $overlay   Aksesibilitas: $acc   ACTG: $svc"
    }

    private fun start() {
        saveFields()
        when {
            !Settings.canDrawOverlays(this) -> toast("Izinkan overlay dulu")
            ControlService.instance == null -> toast("Aktifkan Aksesibilitas ACTG dulu")
            prefs.apiKey.isBlank() -> toast("Isi API key dulu")
            else -> {
                val mgr = getSystemService(MediaProjectionManager::class.java)
                captureLauncher.launch(mgr.createScreenCaptureIntent())
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
