package com.actg.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Swipe dari (x1,y1) ke (x2,y2) selama [ms] milidetik. */
data class Swipe(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val ms: Long)

/**
 * "Jari" ACTG: menyuntikkan sentuhan ke layar pada koordinat tombol virtual.
 * Harus diaktifkan manual oleh pengguna di Pengaturan > Aksesibilitas.
 */
class ControlService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ControlService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Jalankan beberapa tekanan (x, y, durasi tahan ms) dan swipe sekaligus dalam satu gesture. */
    fun perform(taps: List<Triple<Float, Float, Long>>, swipes: List<Swipe>) {
        if (taps.isEmpty() && swipes.isEmpty()) return
        val builder = GestureDescription.Builder()
        taps.take(5).forEach { (x, y, hold) ->
            val path = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, hold.coerceIn(30L, 3000L)))
        }
        swipes.take(3).forEach { s ->
            val path = Path().apply {
                moveTo(s.x1, s.y1)
                lineTo(s.x2, s.y2)
            }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, s.ms.coerceIn(50L, 3000L)))
        }
        dispatchGesture(builder.build(), null, null)
    }
}
