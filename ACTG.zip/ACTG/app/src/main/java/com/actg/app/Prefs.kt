package com.actg.app

import android.content.Context
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject

/** Satu tombol virtual yang bisa "ditekan" AI. */
data class GameButton(val name: String, val hint: String, val holdMs: Long)

fun defaultModel(provider: String) = when (provider) {
    "openai" -> "gpt-4o-mini"
    "gemini" -> "gemini-2.0-flash"
    else -> "claude-haiku-5-5"
}

fun isLandscape(ctx: Context): Boolean {
    val b = ctx.getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
    return b.width() > b.height()
}

class Prefs(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("actg", Context.MODE_PRIVATE)

    /** "anthropic" | "openai" | "gemini" */
    var provider: String
        get() = sp.getString("provider", "anthropic") ?: "anthropic"
        set(v) = sp.edit().putString("provider", v).apply()

    /** API key disimpan per penyedia. */
    var apiKey: String
        get() = sp.getString("api_key_$provider", "") ?: ""
        set(v) = sp.edit().putString("api_key_$provider", v.trim()).apply()

    var model: String
        get() = (sp.getString("model_$provider", null) ?: "").ifBlank { defaultModel(provider) }
        set(v) = sp.edit().putString("model_$provider", v.trim()).apply()

    var goal: String
        get() = sp.getString(
            "goal",
            "Mainkan game ini sebaik mungkin: hindari bahaya, kumpulkan poin, dan bertahan selama mungkin."
        ) ?: ""
        set(v) = sp.edit().putString("goal", v.trim()).apply()

    var intervalMs: Long
        get() = sp.getLong("interval_ms", 1500L)
        set(v) = sp.edit().putLong("interval_ms", v.coerceIn(500L, 30000L)).apply()

    fun buttons(): List<GameButton> {
        val raw = sp.getString("buttons", null) ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                GameButton(o.getString("name"), o.optString("hint"), o.optLong("hold", 150L))
            }
        } catch (e: Exception) {
            defaults()
        }
    }

    fun saveButtons(list: List<GameButton>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("name", it.name).put("hint", it.hint).put("hold", it.holdMs))
        }
        sp.edit().putString("buttons", arr.toString()).apply()
    }

    private fun defaults() = listOf(
        GameButton("LEFT", "Gerak ke kiri", 300),
        GameButton("RIGHT", "Gerak ke kanan", 300),
        GameButton("JUMP", "Lompat", 120),
        GameButton("ATTACK", "Serang", 120),
    )

    /** Posisi pusat tombol (piksel layar). Disimpan terpisah untuk portrait & landscape. */
    fun position(name: String, landscape: Boolean): Pair<Int, Int> {
        val saved = sp.getString(key(name, landscape), null)
        if (saved != null) {
            val p = saved.split(",")
            if (p.size == 2) return p[0].toInt() to p[1].toInt()
        }
        val b = ctx.getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        val idx = buttons().indexOfFirst { it.name == name }.coerceAtLeast(0)
        val x = (b.width() * (0.12 + 0.14 * idx)).toInt().coerceAtMost(b.width() - 60)
        val y = (b.height() * 0.8).toInt()
        return x to y
    }

    fun setPosition(name: String, landscape: Boolean, x: Int, y: Int) {
        sp.edit().putString(key(name, landscape), "$x,$y").apply()
    }

    private fun key(name: String, landscape: Boolean) = "pos_${if (landscape) "l" else "p"}_$name"
}
