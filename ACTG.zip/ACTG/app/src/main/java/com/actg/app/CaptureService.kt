package com.actg.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.view.WindowManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * Mata + otak ACTG: menangkap layar (MediaProjection), mengirim ke AI, lalu
 * meminta ControlService menekan tombol virtual yang dipilih AI.
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "actg"

        @Volatile
        var running = false
    }

    private lateinit var prefs: Prefs
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: Overlay? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private var lastJpeg: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Wajib dipanggil dulu (Android 14+), sebelum getMediaProjection.
        startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        if (intent == null || projection != null) return START_NOT_STICKY

        prefs = Prefs(this)
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val mgr = getSystemService(MediaProjectionManager::class.java)
        projection = mgr.getMediaProjection(code, data).also { p ->
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))
        }
        setupDisplay()

        overlay = Overlay(
            this, prefs,
            onToggle = { on -> if (on) startLoop() else stopLoop() },
            onClose = { stopSelf() },
        ).also { it.show() }

        running = true
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setupDisplay()
        overlay?.onScreenChanged()
    }

    override fun onDestroy() {
        running = false
        stopLoop()
        scope.cancel()
        overlay?.hide()
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        super.onDestroy()
    }

    // ---------- tangkap layar ----------

    private fun setupDisplay() {
        val p = projection ?: return
        val bounds = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        val w = bounds.width()
        val h = bounds.height()
        val dpi = resources.displayMetrics.densityDpi

        val oldReader = reader
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = newReader

        val vd = display
        if (vd == null) {
            display = p.createVirtualDisplay(
                "actg", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, null
            )
        } else {
            vd.resize(w, h, dpi)
            vd.surface = newReader.surface
        }
        runCatching { oldReader?.close() }
    }

    private fun grabJpeg(): String? {
        val r = reader ?: return lastJpeg
        val img = r.acquireLatestImage() ?: return lastJpeg // layar statis -> pakai frame terakhir
        try {
            val plane = img.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * img.width
            val full = Bitmap.createBitmap(
                img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
            )
            full.copyPixelsFromBuffer(plane.buffer)
            val crop = Bitmap.createBitmap(full, 0, 0, img.width, img.height)

            val scale = minOf(1f, 1024f / maxOf(crop.width, crop.height))
            val out = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    crop, (crop.width * scale).toInt(), (crop.height * scale).toInt(), true
                )
            } else crop

            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 70, bos)
            lastJpeg = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            return lastJpeg
        } finally {
            img.close()
        }
    }

    // ---------- loop AI ----------

    private fun stopLoop() {
        loop?.cancel()
        loop = null
        overlay?.setStatus("Dijeda.")
    }

    private fun startLoop() {
        if (loop?.isActive == true) return
        loop = scope.launch {
            val history = ArrayDeque<String>()
            while (isActive) {
                val t0 = SystemClock.elapsedRealtime()
                try {
                    val jpeg = grabJpeg()
                    if (jpeg == null) {
                        overlay?.setStatus("Menunggu frame layar…")
                        delay(300)
                        continue
                    }
                    val key = prefs.apiKey
                    if (key.isBlank()) {
                        overlay?.setStatus("API key kosong. Isi di aplikasi ACTG.")
                        delay(2000)
                        continue
                    }
                    val buttons = prefs.buttons()
                    val client = AiClient(prefs.provider, key, prefs.model)
                    val decision = withContext(Dispatchers.IO) {
                        client.decide(jpeg, prefs.goal, buttons, history.toList())
                    }

                    val svc = ControlService.instance
                    if (svc == null) {
                        overlay?.setStatus("Aksesibilitas ACTG belum aktif.")
                    } else {
                        val land = isLandscape(this@CaptureService)
                        val points = decision.presses.mapNotNull { pr ->
                            val bn = pr.button ?: return@mapNotNull null
                            buttons.firstOrNull { it.name.equals(bn, ignoreCase = true) }?.let { b ->
                                val (x, y) = prefs.position(b.name, land)
                                Triple(x.toFloat(), y.toFloat(), pr.holdMs ?: b.holdMs)
                            }
                        }
                        val bounds = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
                        val swipes = decision.presses.mapNotNull { pr ->
                            pr.swipe?.let { swipeFor(it, bounds.width(), bounds.height()) }
                        }
                        svc.perform(points, swipes)
                        val names = decision.presses
                            .joinToString("+") { it.button ?: "swipe-${it.swipe}" }
                            .ifEmpty { "tunggu" }
                        history.addLast(names)
                        while (history.size > 5) history.removeFirst()
                        overlay?.setStatus("$names — ${decision.reason}")
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    overlay?.setStatus("Error: ${e.message}")
                    delay(2000)
                }
                val elapsed = SystemClock.elapsedRealtime() - t0
                delay((prefs.intervalMs - elapsed).coerceAtLeast(100))
            }
        }
    }

    /** Swipe dari tengah layar; arah = arah gerak jari. */
    private fun swipeFor(dir: String, w: Int, h: Int): Swipe? {
        val cx = w / 2f
        val cy = h / 2f
        val dx = w * 0.3f
        val dy = h * 0.3f
        return when (dir.uppercase()) {
            "LEFT" -> Swipe(cx + dx, cy, cx - dx, cy, 250)
            "RIGHT" -> Swipe(cx - dx, cy, cx + dx, cy, 250)
            "UP" -> Swipe(cx, cy + dy, cx, cy - dy, 250)
            "DOWN" -> Swipe(cx, cy - dy, cx, cy + dy, 250)
            else -> null
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "ACTG", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("ACTG aktif")
            .setContentText("AI melihat layar dan siap menekan tombol")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }
}
