package com.actg.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.tabs.TabLayout
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var etKey: TextInputEditText
    private lateinit var etModel: TextInputEditText
    private lateinit var etGoal: TextInputEditText
    private lateinit var etInterval: TextInputEditText
    private lateinit var buttonList: android.widget.LinearLayout
    private lateinit var btnStart: MaterialButton

    private val providers = mapOf(
        R.id.pClaude to "anthropic",
        R.id.pOpenAI to "openai",
        R.id.pGemini to "gemini",
    )

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .putExtra(CaptureService.EXTRA_CODE, r.resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                toast("ACTG aktif. Buka game-nya, atur tombol, lalu tekan ▶ di panel.")
            } else {
                toast("Izin tangkap layar ditolak.")
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        applyInsets()

        etKey = findViewById(R.id.etKey)
        etModel = findViewById(R.id.etModel)
        etGoal = findViewById(R.id.etGoal)
        etInterval = findViewById(R.id.etInterval)
        buttonList = findViewById(R.id.buttonList)
        btnStart = findViewById(R.id.btnStart)

        etKey.setText(prefs.apiKey)
        etModel.setText(prefs.model)
        etGoal.setText(prefs.goal)
        etInterval.setText(prefs.intervalMs.toString())

        // Penyedia AI: key & model disimpan terpisah per penyedia.
        val group = findViewById<MaterialButtonToggleGroup>(R.id.providerGroup)
        group.check(providers.entries.firstOrNull { it.value == prefs.provider }?.key ?: R.id.pClaude)
        group.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            saveFields() // simpan key & model milik penyedia lama
            prefs.provider = providers[id] ?: "anthropic"
            etKey.setText(prefs.apiKey)
            etModel.setText(prefs.model)
        }

        findViewById<View>(R.id.btnPreset).setOnClickListener { etGoal.setText(PRESET_SURVIVAL) }
        findViewById<View>(R.id.btnAdd).setOnClickListener { addDialog() }
        findViewById<View>(R.id.btnOverlay).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        findViewById<View>(R.id.btnAcc).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnStart.setOnClickListener {
            if (CaptureService.running) {
                stopService(Intent(this, CaptureService::class.java))
                setRunningUi(false)
            } else {
                start()
            }
        }

        refreshButtons()
        setupTabs()
        buildGameList()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onPause() {
        super.onPause()
        saveFields()
    }

    // ---------- tampilan ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun applyInsets() {
        val root = findViewById<View>(R.id.root)
        val bar = findViewById<View>(R.id.bottomBar)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, 0)
            bar.setPadding(dp(12), dp(12), dp(12), dp(12) + b.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun tint(dot: View, color: Int) {
        dot.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
    }

    private fun refreshStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val accOk = ControlService.instance != null

        tint(findViewById(R.id.dotOverlay), if (overlayOk) R.color.actg_ok else R.color.actg_bad)
        tint(findViewById(R.id.dotAcc), if (accOk) R.color.actg_ok else R.color.actg_bad)
        findViewById<View>(R.id.btnOverlay).visibility = if (overlayOk) View.GONE else View.VISIBLE
        findViewById<View>(R.id.btnAcc).visibility = if (accOk) View.GONE else View.VISIBLE

        setRunningUi(CaptureService.running)
    }

    private fun setRunningUi(running: Boolean) {
        tint(findViewById(R.id.dotRun), if (running) R.color.actg_ok else R.color.actg_muted)
        findViewById<TextView>(R.id.txtRun).text = if (running) "ACTG berjalan" else "ACTG berhenti"
        btnStart.text = if (running) "Hentikan ACTG" else "Mulai ACTG"
        btnStart.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (running) R.color.actg_bad else R.color.actg_cyan)
        )
        btnStart.setTextColor(ContextCompat.getColor(this, R.color.actg_bg))
    }

    private fun setupTabs() {
        val tabs = findViewById<TabLayout>(R.id.tabs)
        val settings = findViewById<View>(R.id.sectionSettings)
        val games = findViewById<View>(R.id.sectionGames)
        tabs.addTab(tabs.newTab().setText("Pengaturan"))
        tabs.addTab(tabs.newTab().setText("Game"))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                val g = tab.position == 1
                settings.visibility = if (g) View.GONE else View.VISIBLE
                games.visibility = if (g) View.VISIBLE else View.GONE
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    private fun kindLabel(b: GameButton) = when (b.dir) {
        "UP" -> "Joystick ↑"
        "DOWN" -> "Joystick ↓"
        "LEFT" -> "Joystick ←"
        "RIGHT" -> "Joystick →"
        "HOLD" -> "Tahan"
        else -> "Tap"
    }

    private fun buildGameList() {
        val list = findViewById<android.widget.LinearLayout>(R.id.gameList)
        Games.all.forEach { g ->
            val card = layoutInflater.inflate(R.layout.item_game, list, false)
            card.findViewById<TextView>(R.id.gName).text = g.name
            card.findViewById<TextView>(R.id.gTagline).text = g.tagline
            card.findViewById<TextView>(R.id.gButtons).text =
                "${g.buttons.size} tombol:\n" + g.buttons.joinToString("\n") {
                    "• ${it.name}  (${kindLabel(it)})"
                }
            card.findViewById<View>(R.id.gApply).setOnClickListener { confirmApply(g) }
            list.addView(card)
        }
    }

    private fun confirmApply(g: GameProfile) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Terapkan ${g.name}?")
            .setMessage(
                "Daftar tombol dan tujuan AI sekarang akan DIGANTI dengan profil ini " +
                    "(${g.buttons.size} tombol dibuat otomatis). Posisi lingkaran yang pernah kamu atur " +
                    "untuk tombol bernama sama tetap dipakai."
            )
            .setPositiveButton("Terapkan") { _, _ ->
                prefs.saveButtons(g.buttons)
                prefs.goal = g.goal
                etGoal.setText(g.goal)
                refreshButtons()
                findViewById<TabLayout>(R.id.tabs).getTabAt(0)?.select()
                toast("Profil ${g.name} diterapkan. Buka game, lalu geser lingkaran ke tombolnya (✎ di panel).")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshButtons() {
        buttonList.removeAllViews()
        prefs.buttons().forEach { b ->
            val row = layoutInflater.inflate(R.layout.item_button, buttonList, false)
            row.findViewById<TextView>(R.id.tvName).text = b.name
            row.findViewById<TextView>(R.id.tvHint).text =
                b.hint.ifBlank { "(tanpa keterangan)" } + " · ${b.holdMs} ms"
            row.findViewById<TextView>(R.id.tvKind).text = kindLabel(b)
            row.findViewById<View>(R.id.tvDelete).setOnClickListener {
                prefs.saveButtons(prefs.buttons().filter { it.name != b.name })
                refreshButtons()
            }
            buttonList.addView(row)
        }
    }

    private fun addDialog() {
        val v = layoutInflater.inflate(R.layout.dialog_add_button, null)
        val n = v.findViewById<TextInputEditText>(R.id.dName)
        val h = v.findViewById<TextInputEditText>(R.id.dHint)
        val d = v.findViewById<TextInputEditText>(R.id.dHold)
        val dd = v.findViewById<MaterialAutoCompleteTextView>(R.id.dKind)

        val kinds = listOf(
            "Tap biasa", "Tahan / hold (mis. SPRINT)",
            "Joystick ATAS (maju)", "Joystick BAWAH (mundur)", "Joystick KIRI", "Joystick KANAN"
        )
        val dirs = listOf("", "HOLD", "UP", "DOWN", "LEFT", "RIGHT")
        var selected = 0
        dd.setSimpleItems(kinds.toTypedArray())
        dd.setText(kinds[0], false)
        dd.setOnItemClickListener { _, _, pos, _ -> selected = pos }

        MaterialAlertDialogBuilder(this)
            .setTitle("Tambah tombol")
            .setView(v)
            .setPositiveButton("Tambah") { _, _ ->
                val name = n.text.toString().trim().uppercase().replace(" ", "_")
                val current = prefs.buttons()
                if (name.isEmpty() || name == JOYSTICK || name == CAMERA || name == "STOP" ||
                    current.any { it.name == name }
                ) {
                    toast("Nama kosong, sudah dipakai, atau dicadangkan")
                } else {
                    val dir = dirs[selected]
                    val hold = d.text.toString().toLongOrNull() ?: if (dir == "" || dir == "HOLD") 150L else 600L
                    prefs.saveButtons(current + GameButton(name, h.text.toString().trim(), hold, dir))
                    refreshButtons()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- logika ----------

    private fun saveFields() {
        if (!::etKey.isInitialized) return
        prefs.apiKey = etKey.text.toString()
        prefs.model = etModel.text.toString().ifBlank { defaultModel(prefs.provider) }
        prefs.goal = etGoal.text.toString()
        prefs.intervalMs = etInterval.text.toString().toLongOrNull() ?: 500L
    }

    private fun start() {
        saveFields()
        when {
            !Settings.canDrawOverlays(this) -> toast("Izinkan overlay dulu")
            ControlService.instance == null -> toast("Aktifkan layanan Aksesibilitas ACTG dulu")
            prefs.apiKey.isBlank() -> toast("Isi API key dulu")
            else -> {
                val mgr = getSystemService(MediaProjectionManager::class.java)
                captureLauncher.launch(mgr.createScreenCaptureIntent())
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
