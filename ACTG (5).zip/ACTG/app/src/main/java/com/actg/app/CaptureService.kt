package com.actg.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.view.WindowManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * Mata + otak ACTG: menangkap layar (MediaProjection), mengirim ke AI, lalu
 * meminta ControlService menekan tombol virtual yang dipilih AI.
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "actg"
        private const val THUMB_W = 48
        private const val THUMB_H = 27

        /** Rata-rata selisih piksel (0-255) di bawah ini = layar dianggap tidak bergerak. */
        private const val STUCK_DIFF = 2.5

        @Volatile
        var running = false
    }

    private lateinit var prefs: Prefs
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: Overlay? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private var lastJpeg: String? = null
    private var curThumb: IntArray? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Wajib dipanggil dulu (Android 14+), sebelum getMediaProjection.
        startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        if (intent == null || projection != null) return START_NOT_STICKY

        prefs = Prefs(this)
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra<Intent>(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val mgr = getSystemService(MediaProjectionManager::class.java)
        projection = mgr.getMediaProjection(code, data).also { p ->
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))
        }
        setupDisplay()

        overlay = Overlay(
            this, prefs,
            onToggle = { on -> if (on) startLoop() else stopLoop() },
            onClose = { stopSelf() },
        ).also { it.show() }

        running = true
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setupDisplay()
        overlay?.onScreenChanged()
    }

    override fun onDestroy() {
        running = false
        stopLoop()
        scope.cancel()
        overlay?.hide()
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        super.onDestroy()
    }

    // ---------- tangkap layar ----------

    private fun setupDisplay() {
        val p = projection ?: return
        val bounds = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        val w = bounds.width()
        val h = bounds.height()
        val dpi = resources.displayMetrics.densityDpi

        val oldReader = reader
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = newReader

        val vd = display
        if (vd == null) {
            display = p.createVirtualDisplay(
                "actg", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, null
            )
        } else {
            vd.resize(w, h, dpi)
            vd.surface = newReader.surface
        }
        runCatching { oldReader?.close() }
    }

    private fun grabJpeg(): String? {
        val r = reader ?: return lastJpeg
        val img = r.acquireLatestImage() ?: return lastJpeg // layar statis -> pakai frame terakhir
        try {
            val plane = img.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * img.width
            val full = Bitmap.createBitmap(
                img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
            )
            full.copyPixelsFromBuffer(plane.buffer)
            val crop = Bitmap.createBitmap(full, 0, 0, img.width, img.height)

            // 768 px sisi terpanjang: cukup untuk dibaca AI, upload & inferensi lebih cepat
            val scale = minOf(1f, 768f / maxOf(crop.width, crop.height))
            val out = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    crop, (crop.width * scale).toInt(), (crop.height * scale).toInt(), true
                )
            } else crop

            // Thumbnail abu-abu 48x27 untuk mendeteksi layar yang tidak berubah (karakter macet)
            val th = Bitmap.createScaledBitmap(out, THUMB_W, THUMB_H, true)
            val px = IntArray(THUMB_W * THUMB_H)
            th.getPixels(px, 0, THUMB_W, 0, 0, THUMB_W, THUMB_H)
            curThumb = IntArray(px.size) {
                val c = px[it]
                (((c shr 16) and 0xFF) * 3 + ((c shr 8) and 0xFF) * 6 + (c and 0xFF)) / 10
            }

            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 60, bos)
            lastJpeg = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            return lastJpeg
        } finally {
            img.close()
        }
    }

    // ---------- loop AI ----------

    private fun stopLoop() {
        loop?.cancel()
        loop = null
        ControlService.instance?.releaseMove()
        overlay?.setStatus("Dijeda.")
    }

    private fun startLoop() {
        if (loop?.isActive == true) return
        loop = scope.launch {
            val history = ArrayDeque<String>()
            var moving = "" // arah joystick yang sedang ditahan ("" = diam)
            var prevThumb: IntArray? = null
            var turnRight = true
            var swipeCooldown = 0 // giliran tersisa di mana swipe kamera dari AI diabaikan
            val heldNames = LinkedHashSet<String>() // tombol tahan yang sedang aktif (mis. SPRINT)
            while (isActive) {
                val t0 = SystemClock.elapsedRealtime()
                try {
                    val jpeg = grabJpeg()
                    if (jpeg == null) {
                        overlay?.setStatus("Menunggu frame layar…")
                        delay(300)
                        continue
                    }
                    val key = prefs.apiKey
                    if (key.isBlank()) {
                        overlay?.setStatus("API key kosong. Isi di aplikasi ACTG.")
                        delay(2000)
                        continue
                    }
                    val buttons = prefs.buttons()
                    val land0 = isLandscape(this@CaptureService)

                    // Deteksi macet: sedang jalan tapi layar nyaris tidak berubah sejak giliran lalu.
                    var note = ""
                    val cur = curThumb
                    val prev = prevThumb
                    prevThumb = cur
                    if (moving.isNotEmpty() && cur != null && prev != null && cur.size == prev.size) {
                        var sum = 0L
                        for (i in cur.indices) sum += Math.abs(cur[i] - prev[i])
                        val diff = sum.toDouble() / cur.size
                        if (diff < STUCK_DIFF) {
                            val svc0 = ControlService.instance
                            var turned = false
                            if (svc0 != null && swipeCooldown == 0) {
                                // Putar kamera otomatis (joystick tetap ditahan) supaya tidak terus menabrak.
                                swipeFor(if (turnRight) "RIGHT" else "LEFT", "BIG", land0)
                                    ?.let { svc0.perform(null, false, null, emptyList(), listOf(it)) }
                                turnRight = !turnRight
                                swipeCooldown = 1
                                turned = true
                            }
                            note = "STUCK: the screen did not change while walking ($moving), the character is " +
                                "probably blocked by a wall/obstacle. " +
                                (if (turned) "The camera was just auto-turned. " else "") +
                                "Check where open space is and choose a different direction."
                        }
                    }

                    val client = AiClient(prefs.provider, key, prefs.model)
                    val decision = withContext(Dispatchers.IO) {
                        client.decide(
                            jpeg, prefs.goal, buttons, history.toList(), moving, note,
                            heldNames.joinToString("+")
                        )
                    }

                    val svc = ControlService.instance
                    if (svc == null) {
                        overlay?.setStatus("Aksesibilitas ACTG belum aktif.")
                    } else {
                        val land = isLandscape(this@CaptureService)
                        val chosen = decision.presses.mapNotNull { pr ->
                            val bn = pr.button ?: return@mapNotNull null
                            buttons.firstOrNull { it.name.equals(bn, ignoreCase = true) }?.let { it to pr }
                        }
                        val points = chosen.filter { !it.first.isJoy && !it.first.isHold }.map { (b, pr) ->
                            val (x, y) = prefs.position(b.name, land)
                            Triple(x.toFloat(), y.toFloat(), pr.holdMs ?: b.holdMs)
                        }

                        // Tombol tahan: tekan sekali = ditahan, tekan lagi = dilepas (toggle).
                        chosen.filter { it.first.isHold }.map { it.first.name }.distinct().forEach { n ->
                            if (!heldNames.remove(n)) heldNames.add(n)
                        }
                        val holds = heldNames.mapNotNull { n ->
                            buttons.firstOrNull { it.name == n }?.let {
                                val (x, y) = prefs.position(n, land)
                                n to (x.toFloat() to y.toFloat())
                            }
                        }.toMap()

                        // Swipe kamera: maksimal satu per giliran dan tidak berturut-turut.
                        var swipes = decision.presses.mapNotNull { pr ->
                            pr.swipe?.let { swipeFor(it, pr.amount, land) }
                        }.take(1)
                        var camNote = ""
                        if (swipeCooldown > 0) {
                            if (swipes.isNotEmpty()) camNote = " (kamera ditahan)"
                            swipes = emptyList()
                            swipeCooldown--
                        } else if (swipes.isNotEmpty()) {
                            swipeCooldown = 1
                        }

                        // Tombol arah -> joystick sentuh game DITAHAN sampai AI memberi arah baru / STOP
                        // (arah digabung untuk diagonal).
                        var move: Move? = null
                        val stop = decision.presses.any { it.button.equals("STOP", ignoreCase = true) }
                        val moves = chosen.filter { it.first.isJoy }
                        if (moves.isNotEmpty() && !stop) {
                            var vx = 0f
                            var vy = 0f
                            moves.forEach { (b, _) ->
                                when (b.dir) {
                                    "UP" -> vy -= 1f
                                    "DOWN" -> vy += 1f
                                    "LEFT" -> vx -= 1f
                                    "RIGHT" -> vx += 1f
                                }
                            }
                            val len = Math.hypot(vx.toDouble(), vy.toDouble()).toFloat()
                            if (len > 0f) {
                                val (jx, jy) = prefs.position(JOYSTICK, land)
                                val r = 70f * resources.displayMetrics.density
                                move = Move(
                                    jx.toFloat(), jy.toFloat(),
                                    jx + vx / len * r, jy + vy / len * r
                                )
                                moving = moves.joinToString("+") { it.first.name }
                            }
                        }
                        if (stop) moving = ""
                        svc.perform(move, stop, holds, points, swipes)
                        val names = decision.presses
                            .joinToString("+") { it.button ?: "swipe-${it.swipe}" }
                            .ifEmpty { "tunggu" } + camNote
                        history.addLast(names)
                        while (history.size > 5) history.removeFirst()
                        val danger = decision.threat.trim()
                        val warn = if (danger.isNotEmpty() && !danger.equals("none", true)) "⚠ $danger\n" else ""
                        overlay?.setStatus("$warn$names — ${decision.reason}")
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: ApiException) {
                    val m = e.message.orEmpty()
                    val fatal = e.code in listOf(400, 401, 403, 404) ||
                        (e.code == 429 && Regex("credit|quota|billing", RegexOption.IGNORE_CASE).containsMatchIn(m))
                    if (fatal) {
                        val hint = when (e.code) {
                            404 -> "Nama model tidak ditemukan. Ganti model di aplikasi."
                            401, 403 -> "API key ditolak. Cek key & penyedia."
                            429 -> "Kredit/kuota API habis. Isi saldo atau pakai key lain."
                            else -> "Permintaan ditolak."
                        }
                        ControlService.instance?.releaseMove()
                        overlay?.pauseWithMessage("$hint\n($m)")
                        loop = null
                        return@launch
                    }
                    overlay?.setStatus("Server sibuk (${e.code}), coba lagi…")
                    delay(5000)
                } catch (e: Exception) {
                    overlay?.setStatus("Error: ${e.message}")
                    delay(2000)
                }
                val elapsed = SystemClock.elapsedRealtime() - t0
                delay((prefs.intervalMs - elapsed).coerceAtLeast(100))
            }
        }
    }

    /**
     * Swipe kamera di sekitar anchor CAMERA (area bebas di kanan layar), bukan dari tengah layar:
     * swipe dari tengah bisa mulai di sisi kiri yang dipakai joystick game dan ikut menggeser karakter.
     * Arah = arah gerak jari. Titik awal & akhir dijepit supaya tetap di dalam layar.
     */
    private fun swipeFor(dir: String, amount: String?, land: Boolean): Swipe? {
        val b = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val (axI, ayI) = prefs.position(CAMERA, land)
        val ax = axI.toFloat()
        val ay = ayI.toFloat()

        // Setengah panjang swipe (fraksi lebar/tinggi layar).
        val f = when (amount?.uppercase()) {
            "SMALL" -> 0.06f
            "BIG" -> 0.20f
            else -> 0.12f
        }
        val dx = w * f
        val dy = h * f
        fun cx(v: Float) = v.coerceIn(w * 0.03f, w * 0.97f)
        fun cy(v: Float) = v.coerceIn(h * 0.05f, h * 0.95f)
        return when (dir.uppercase()) {
            "LEFT" -> Swipe(cx(ax + dx), cy(ay), cx(ax - dx), cy(ay), 250)
            "RIGHT" -> Swipe(cx(ax - dx), cy(ay), cx(ax + dx), cy(ay), 250)
            "UP" -> Swipe(cx(ax), cy(ay + dy), cx(ax), cy(ay - dy), 250)
            "DOWN" -> Swipe(cx(ax), cy(ay - dy), cx(ax), cy(ay + dy), 250)
            else -> null
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "ACTG", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("ACTG aktif")
            .setContentText("AI melihat layar dan siap menekan tombol")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }
}
