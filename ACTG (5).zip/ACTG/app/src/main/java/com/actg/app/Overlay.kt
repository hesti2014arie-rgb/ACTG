package com.actg.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
import android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
import android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
import android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
import android.view.WindowManager.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Overlay melayang:
 *  - panel kontrol (geser, play/pause, mode edit, tutup)
 *  - tombol virtual berlabel (lingkaran) yang diletakkan di atas tombol game
 * Saat AI berjalan, tombol virtual dibuat tembus sentuhan supaya gesture jatuh ke game.
 */
class Overlay(
    private val ctx: Context,
    private val prefs: Prefs,
    private val onToggle: (Boolean) -> Unit,
    private val onClose: () -> Unit,
) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val ui = Handler(Looper.getMainLooper())
    private val markers = mutableMapOf<String, Pair<TextView, WindowManager.LayoutParams>>()
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private lateinit var statusView: TextView
    private lateinit var toggleBtn: TextView
    private lateinit var editBtn: TextView
    private var running = false
    private var editMode = true
    private val size = dp(64)

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun baseFlags() = FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS

    private fun params(w: Int, h: Int, x: Int, y: Int, flags: Int) =
        WindowManager.LayoutParams(w, h, TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }

    fun show() {
        buildPanel()
        rebuildMarkers()
    }

    fun hide() {
        markers.values.forEach { runCatching { wm.removeView(it.first) } }
        markers.clear()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    fun onScreenChanged() = ui.post { rebuildMarkers() }

    /** Dipanggil saat loop berhenti sendiri karena error (mis. kredit habis). */
    fun pauseWithMessage(text: String) {
        ui.post {
            if (panel == null) return@post
            running = false
            toggleBtn.text = "▶"
            statusView.text = text
        }
    }

    fun setStatus(text: String) {
        ui.post { if (panel != null) statusView.text = text }
    }

    // ---------- panel ----------

    private fun buildPanel() {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#DD1B1B1B"))
            }
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        fun icon(label: String, onClick: () -> Unit) = TextView(ctx).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { onClick() }
        }

        val handle = icon("⠿") {}
        toggleBtn = icon("▶") { toggle() }
        editBtn = icon("✎") {
            if (!running) {
                editMode = !editMode
                applyMode()
            }
        }
        val closeBtn = icon("✕") { onClose() }
        listOf(handle, toggleBtn, editBtn, closeBtn).forEach { row.addView(it) }

        statusView = TextView(ctx).apply {
            text = "Siap. Geser tombol ke posisi tombol game, lalu tekan ▶"
            setTextColor(Color.LTGRAY)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            maxLines = 3
            layoutParams = LinearLayout.LayoutParams(dp(220), WRAP_CONTENT)
        }
        root.addView(row)
        root.addView(statusView)

        val lp = params(WRAP_CONTENT, WRAP_CONTENT, dp(8), dp(80), baseFlags())
        panelParams = lp
        handle.setOnTouchListener(dragListener(lp, root, null))
        wm.addView(root, lp)
        panel = root
    }

    private fun toggle() {
        running = !running
        toggleBtn.text = if (running) "⏸" else "▶"
        if (running) {
            editMode = false
            applyMode()
        }
        onToggle(running)
    }

    // ---------- tombol virtual ----------

    private fun rebuildMarkers() {
        markers.values.forEach { runCatching { wm.removeView(it.first) } }
        markers.clear()
        val land = isLandscape(ctx)
        val all = prefs.buttons()
        // Tombol arah tidak punya lingkaran sendiri: semuanya memakai satu anchor JOYSTICK.
        val shown = all.filter { !it.isJoy } +
            (if (all.any { it.isJoy }) listOf(GameButton(JOYSTICK, "", 0)) else emptyList()) +
            listOf(GameButton(CAMERA, "", 0)) // area putar kamera: letakkan di area kosong kanan layar
        shown.forEach { b ->
            val (cx, cy) = prefs.position(b.name, land)
            val tv = TextView(ctx).apply {
                text = b.name
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                maxLines = 2
            }
            val flags = if (editMode) baseFlags() else baseFlags() or FLAG_NOT_TOUCHABLE
            val lp = params(size, size, cx - size / 2, cy - size / 2, flags)
            tv.setOnTouchListener(dragListener(lp, tv, b.name))
            style(tv)
            wm.addView(tv, lp)
            markers[b.name] = tv to lp
        }
        editBtn.alpha = if (editMode) 1f else 0.5f
    }

    private fun style(tv: TextView) {
        tv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(if (editMode) "#CC1E88E5" else "#55FF9800"))
            setStroke(dp(2), Color.WHITE)
        }
    }

    private fun applyMode() {
        markers.values.forEach { (tv, lp) ->
            lp.flags = if (editMode) baseFlags() else baseFlags() or FLAG_NOT_TOUCHABLE
            style(tv)
            runCatching { wm.updateViewLayout(tv, lp) }
        }
        editBtn.alpha = if (editMode) 1f else 0.5f
    }

    /** Geser view; jika [buttonName] diisi, simpan posisi pusatnya saat jari diangkat. */
    private fun dragListener(lp: WindowManager.LayoutParams, view: View, buttonName: String?) =
        object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var downX = 0f
            var downY = 0f

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        downX = e.rawX; downY = e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = startX + (e.rawX - downX).toInt()
                        lp.y = startY + (e.rawY - downY).toInt()
                        runCatching { wm.updateViewLayout(view, lp) }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (buttonName != null) {
                            prefs.setPosition(buttonName, isLandscape(ctx), lp.x + size / 2, lp.y + size / 2)
                        }
                    }
                }
                return true
            }
        }
}
