package com.actg.app

/** Profil game: paket tombol + tujuan AI yang bisa diterapkan sekali tekan dari tab Game. */
data class GameProfile(
    val name: String,
    val tagline: String,
    val goal: String,
    val buttons: List<GameButton>,
)

object Games {

    private fun walk() = listOf(
        GameButton("MAJU", "Jalan maju", 600, "UP"),
        GameButton("BELAKANG", "Jalan mundur", 600, "DOWN"),
        GameButton("LEFT", "Jalan ke kiri", 600, "LEFT"),
        GameButton("RIGHT", "Jalan ke kanan", 600, "RIGHT"),
    )

    val FORSAKEN = GameProfile(
        name = "FORSAKEN (Roblox)",
        tagline = "Survivor vs killer. Joystick, sprint (tahan), 3 skill, shiftlock, emote.",
        goal = "Ini game Roblox FORSAKEN: kamu SURVIVOR, ada KILLER yang memburu. Ronde punya timer; " +
            "objektif biasanya menyelesaikan puzzle di generator (tertulis di layar, mis. 0/5) lalu bertahan sampai timer habis.\n" +
            "Prioritas:\n" +
            "1) Tiap giliran cari killer di layar (karakter musuh besar/aneh, nama merah, HP turun, layar memerah). " +
            "Kalau killer terlihat atau dekat: LARI menjauh. Putar kamera supaya killer ada di belakang, lalu MAJU dan aktifkan SPRINT. " +
            "Jangan menghadap atau mendekati killer.\n" +
            "2) Kalau killer menyerang dari dekat: pakai SKILL_BLOCK untuk menangkis. SKILL_PUNCH hanya setelah block berhasil. " +
            "SKILL_CHARGE untuk mendorong/stun killer kalau terdesak.\n" +
            "3) Kalau aman: cari dan kerjakan generator, jelajahi lorong. Matikan SPRINT saat aman.\n" +
            "4) Kalau menabrak tembok atau layar tidak berubah: putar kamera dulu, jangan terus MAJU.\n" +
            "Jangan pakai EMOTE dan EMOTE_BHOP, dan jangan sentuh SHIFTLOCK kecuali perlu.",
        buttons = walk() + listOf(
            GameButton("SPRINT", "untuk berlari (dihold)", 150, "HOLD"),
            GameButton("SHIFTLOCK", "shiftlock kamera", 150),
            GameButton("SKILL_CHARGE", "skill ini untuk mendorong killer (1+ stun killer)", 150),
            GameButton("SKILL_PUNCH", "skill ini buat mukul killer (hanya saat skill block berhasil ditangkis)", 150),
            GameButton("SKILL_BLOCK", "skill ini buat menangkis serangan killer", 150),
            GameButton(
                "EMOTE",
                "tombol ini untuk membuka emote page (tekan lagi untuk berhenti saat sedang emote dan tekan lagi kalo mau nutup)",
                150
            ),
            GameButton("EMOTE_BHOP", "tombol ini untuk memilih emote yang ingin dipakai", 150),
        ),
    )

    val ROBLOX_UMUM = GameProfile(
        name = "Roblox umum",
        tagline = "Joystick sentuh + tombol lompat. Dasar untuk game Roblox apa pun.",
        goal = "Mainkan game Roblox ini sebaik mungkin: ikuti objektif yang tertulis di layar, hindari bahaya, " +
            "dan bertahan. Kalau menabrak tembok atau layar tidak berubah, putar kamera dulu.",
        buttons = walk() + listOf(
            GameButton("JUMP", "Lompat", 150),
            GameButton("SPRINT", "untuk berlari (dihold)", 150, "HOLD"),
        ),
    )

    val PLATFORMER = GameProfile(
        name = "Platformer 2D",
        tagline = "Tombol kiri/kanan (ditekan), lompat, serang. Untuk game tombol layar biasa.",
        goal = "Mainkan game ini sebaik mungkin: hindari bahaya, kumpulkan poin, dan bertahan selama mungkin.",
        buttons = listOf(
            GameButton("LEFT", "Gerak ke kiri", 300),
            GameButton("RIGHT", "Gerak ke kanan", 300),
            GameButton("JUMP", "Lompat", 120),
            GameButton("ATTACK", "Serang", 120),
        ),
    )

    val all = listOf(FORSAKEN, ROBLOX_UMUM, PLATFORMER)
}
