package com.actg.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/** Swipe dari (x1,y1) ke (x2,y2) selama [ms] milidetik. */
data class Swipe(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val ms: Long)

/** Joystick sentuh: jari turun di (cx,cy), digeser ke (tx,ty), lalu DITAHAN di sana. */
data class Move(val cx: Float, val cy: Float, val tx: Float, val ty: Float)

/**
 * "Jari" ACTG: menyuntikkan sentuhan ke layar.
 *
 * Joystick dan tombol "tahan" (mis. SPRINT) ditahan terus-menerus memakai stroke bersambung
 * (willContinue + continueStroke): jari tetap menempel sampai AI melepasnya (STOP / tekan lagi),
 * atau sampai tidak ada perintah baru selama [MAX_HOLD_MS] (pengaman jika loop AI mati).
 * Tap/swipe lain digabung ke gesture yang sama, jadi tidak memutus yang sedang ditahan.
 *
 * Batas Android: maksimal 10 stroke per gesture -> 1 joystick + 2 tahan + 4 tap + 2 swipe = 9.
 *
 * Harus diaktifkan manual oleh pengguna di Pengaturan > Aksesibilitas.
 */
class ControlService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ControlService? = null

        private const val FRAME_MS = 300L       // panjang tiap potongan tahan
        private const val MAX_HOLD_MS = 10000L  // lepas semua jika tidak ada perintah baru selama ini
    }

    private class Held(val x: Float, val y: Float, var stroke: StrokeDescription)

    private val main = Handler(Looper.getMainLooper())

    // Semua state di bawah hanya disentuh dari main thread.
    private var stick: StrokeDescription? = null // stroke joystick yang sedang menempel
    private var fingerX = 0f
    private var fingerY = 0f
    private var target: Move? = null
    private var release = false
    private var pumping = false
    private var lastCmdAt = 0L
    private val desired = LinkedHashMap<String, Pair<Float, Float>>() // tombol tahan yang DIINGINKAN
    private val active = LinkedHashMap<String, Held>()                // tombol tahan yang jarinya sedang turun
    private val tapQueue = ArrayList<Triple<Float, Float, Long>>()
    private val swipeQueue = ArrayList<Swipe>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        main.removeCallbacksAndMessages(null)
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        main.post { resetState() }
    }

    // ---------- API untuk CaptureService (aman dipanggil dari thread mana pun) ----------

    /**
     * @param move      arah joystick baru (null = jangan ubah)
     * @param stopMove  true = lepas joystick
     * @param holds     daftar LENGKAP tombol tahan yang harus aktif (nama -> posisi); null = jangan ubah
     */
    fun perform(
        move: Move?,
        stopMove: Boolean,
        holds: Map<String, Pair<Float, Float>>?,
        taps: List<Triple<Float, Float, Long>>,
        swipes: List<Swipe>,
    ) {
        main.post {
            lastCmdAt = SystemClock.elapsedRealtime()
            if (move != null) {
                target = move
                release = false
            } else if (stopMove) {
                release = true
            }
            if (holds != null) {
                desired.clear()
                holds.entries.take(2).forEach { desired[it.key] = it.value }
            }
            tapQueue.addAll(taps)
            swipeQueue.addAll(swipes)
            pump()
        }
    }

    /** Lepas semua yang ditahan (dipanggil saat AI dijeda/error/ditutup). */
    fun releaseMove() {
        main.post {
            release = true
            desired.clear()
            pump()
        }
    }

    // ---------- mesin gesture ----------

    private fun resetState() {
        stick = null
        target = null
        release = false
        pumping = false
        desired.clear()
        active.clear()
        tapQueue.clear()
        swipeQueue.clear()
    }

    private fun pump() {
        if (pumping) return
        if (stick == null && target == null && active.isEmpty() && desired.isEmpty() &&
            tapQueue.isEmpty() && swipeQueue.isEmpty()
        ) return
        dispatchFrame()
    }

    private fun dispatchFrame() {
        // Pengaman: loop AI berhenti memberi perintah -> lepas semuanya.
        val holding = stick != null || target != null || active.isNotEmpty() || desired.isNotEmpty()
        if (holding && SystemClock.elapsedRealtime() - lastCmdAt > MAX_HOLD_MS) {
            release = true
            desired.clear()
        }

        val b = GestureDescription.Builder()
        var any = false

        // 1) joystick
        val t = target
        if (release) {
            val s = stick
            if (s != null) {
                val p = Path().apply { moveTo(fingerX, fingerY) }
                b.addStroke(s.continueStroke(p, 0, 50, false)) // angkat jari
                any = true
            }
            stick = null
            target = null
            release = false
        } else if (t != null) {
            val s = stick
            val ns: StrokeDescription
            if (s == null) {
                val p = Path().apply {
                    moveTo(t.cx, t.cy)
                    lineTo(t.tx, t.ty)
                }
                ns = StrokeDescription(p, 0, 150, true)
            } else {
                val p = Path().apply {
                    moveTo(fingerX, fingerY)
                    if (fingerX != t.tx || fingerY != t.ty) lineTo(t.tx, t.ty)
                }
                ns = s.continueStroke(p, 0, FRAME_MS, true)
            }
            fingerX = t.tx
            fingerY = t.ty
            stick = ns
            b.addStroke(ns)
            any = true
        }

        // 2) tombol tahan (SPRINT dst.)
        val iter = active.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            val h = e.value
            if (e.key !in desired) {
                val p = Path().apply { moveTo(h.x, h.y) }
                b.addStroke(h.stroke.continueStroke(p, 0, 50, false)) // lepas
                any = true
                iter.remove()
            } else {
                val p = Path().apply { moveTo(h.x, h.y) }
                val ns = h.stroke.continueStroke(p, 0, FRAME_MS, true)
                h.stroke = ns
                b.addStroke(ns)
                any = true
            }
        }
        for ((name, pos) in desired) {
            if (name in active) continue
            val p = Path().apply { moveTo(pos.first, pos.second) }
            val ns = StrokeDescription(p, 0, FRAME_MS, true)
            active[name] = Held(pos.first, pos.second, ns)
            b.addStroke(ns)
            any = true
        }

        // 3) tap & swipe dari AI (digabung agar tidak memutus yang ditahan)
        val taps = tapQueue.take(4)
        val swipes = swipeQueue.take(2)
        tapQueue.clear()
        swipeQueue.clear()
        taps.forEach { (x, y, hold) ->
            val path = Path().apply { moveTo(x, y) }
            b.addStroke(StrokeDescription(path, 0, hold.coerceIn(30L, 3000L)))
            any = true
        }
        swipes.forEach { s ->
            val path = Path().apply {
                moveTo(s.x1, s.y1)
                lineTo(s.x2, s.y2)
            }
            b.addStroke(StrokeDescription(path, 0, s.ms.coerceIn(50L, 3000L)))
            any = true
        }

        if (!any) return

        pumping = true
        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                pumping = false
                pump()
            }

            override fun onCancelled(gestureDescription: GestureDescription) {
                // Jari sudah terputus (mis. pengguna menyentuh layar). Mulai ulang dari awal jika masih perlu.
                pumping = false
                stick = null
                active.clear()
                main.postDelayed({ pump() }, 80)
            }
        }, main)
        if (!ok) {
            pumping = false
            stick = null
            active.clear()
        }
    }
}
