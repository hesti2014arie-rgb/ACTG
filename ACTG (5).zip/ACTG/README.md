# ACTG — AI Control The Game

Aplikasi Android (Kotlin) di mana **AI melihat layar game** dan **mengontrolnya lewat tombol visual** di layar.

```
 Screenshot layar ──► Claude (vision) ──► "tekan JUMP + RIGHT" ──► sentuhan di posisi tombol
   (MediaProjection)      (Anthropic API)                            (AccessibilityService)
```

## Cara kerja

1. **Tombol virtual** — lingkaran berlabel (LEFT, RIGHT, JUMP, ATTACK, dst.) yang kamu geser sendiri
   ke atas tombol kontrol game. Posisi disimpan terpisah untuk portrait & landscape.
2. **AI melihat** — `CaptureService` menangkap layar tiap beberapa detik dan mengirimnya ke Claude.
   Lingkaran berlabel ikut terlihat di screenshot, jadi AI tahu tombol mana ada di mana.
3. **AI mengontrol** — Claude membalas JSON (`{"actions":[{"button":"JUMP"}]}`), lalu
   `ControlService` (Accessibility) menyuntikkan sentuhan di posisi tombol itu.

## Build

### Opsi A — GitHub Actions (tanpa Android Studio)
1. Upload semua isi folder ini ke repo GitHub.
2. Buka tab **Actions → Build APK** (jalan otomatis saat push).
3. Unduh `ACTG-debug-apk` dari bagian *Artifacts*, instal `app-debug.apk` di HP.

### Opsi B — Android Studio
Buka folder ini → tunggu Gradle sync → **Run**. (Butuh JDK 17.)

## Cara pakai

1. Buka ACTG → **Izinkan tampil di atas aplikasi lain**.
2. **Aktifkan layanan Aksesibilitas ACTG** (Pengaturan → Aksesibilitas → ACTG).
3. Pilih penyedia AI (**Claude / OpenAI / Gemini**), isi API key-nya, tujuan AI (mis. "Selesaikan level, hindari musuh"), dan atur daftar tombol.
4. Tekan **Mulai ACTG** → di dialog tangkap layar pilih **"Seluruh layar"** (bukan satu aplikasi!).
5. Buka game. Panel kecil muncul:
   - `⠿` geser panel · `✎` mode edit (geser lingkaran ke tombol game) · `▶/⏸` jalankan/jeda AI · `✕` tutup
6. Letakkan lingkaran di atas tombol game, lalu tekan `▶`.

## Tab Game (profil otomatis)

Tab **Game** membuat daftar tombol + tujuan AI sekali tekan. Tersedia: **FORSAKEN (Roblox)**, Roblox umum,
Platformer 2D. Setelah diterapkan, buka game, tekan ✎ di panel, lalu geser tiap lingkaran ke tombolnya.
Profil baru ditambah di `Games.kt`.

Jenis tombol: **Tap**, **Tahan/hold** (mis. SPRINT: tekan sekali = ditahan, tekan lagi = lepas) dan
**Joystick** (ATAS/BAWAH/KIRI/KANAN).

## Aksi yang bisa dilakukan AI

- Menekan satu atau beberapa tombol virtual sekaligus (dengan lama tahan opsional).
- **Tombol arah (joystick)**: game seperti Roblox memakai joystick sentuh, bukan tombol. Tombol dengan
  tipe "Joystick ATAS/BAWAH/KIRI/KANAN" tidak punya lingkaran sendiri; semuanya memakai satu lingkaran
  **JOYSTICK**. Letakkan lingkaran itu di tengah joystick game (kiri-bawah). Saat AI memilih mis. `MAJU`,
  ACTG men-drag jari dari lingkaran itu ke atas lalu **menahannya terus** (jari tidak diangkat) sampai AI
  memilih arah lain atau tombol `STOP`. `MAJU` + `RIGHT` = diagonal. Tap skill dll. tidak memutus joystick.
  Pengaman: joystick dilepas otomatis jika AI tidak memberi perintah baru selama 8 detik, atau saat ⏸/error.
- **Deteksi macet**: kalau sedang jalan tapi layar hampir tidak berubah antar giliran (menabrak tembok),
  ACTG otomatis memutar kamera ±120° dan memberi tahu AI. Ambang ada di `STUCK_DIFF` (CaptureService.kt).
- **Deteksi bahaya**: AI wajib mengisi `threat` tiap giliran (killer/musuh + posisinya); tampil di panel sebagai ⚠.
  Tombol "Isi contoh tujuan: survival vs killer" di aplikasi mengisi prompt yang cocok untuk game survival Roblox.
- Swipe kamera `UP / DOWN / LEFT / RIGHT` (ukuran `SMALL / NORMAL / BIG`) di sekitar lingkaran **CAMERA**
  (letakkan di area kosong kanan layar; swipe tidak lagi dari tengah layar). Maksimal satu per giliran dan tidak berturut-turut. (memutar kamera di Roblox; juga untuk game geser).

## Catatan & batasan

- **Biaya & latensi**: tiap keputusan = 1 panggilan API dengan gambar. Default model `claude-haiku-5-5`
  (cepat/murah), jeda 1,5 detik. Game real-time cepat (reflex) tidak cocok; game turn-based, puzzle,
  idle, atau santai paling cocok.
- **API key** disimpan lokal di SharedPreferences HP (tidak dienkripsi). Jangan commit key ke GitHub.
- Hanya layar yang ditangkap yang dikirim ke API; jangan jalankan saat ada info sensitif di layar.
- Pakai untuk game **single-player**. Banyak game online melarang bot/otomasi (risiko banned).
- Minimal Android 11 (API 30).

## Struktur

```
app/src/main/java/com/actg/app/
├── MainActivity.kt     halaman pengaturan (layout di res/layout/activity_main.xml)
├── CaptureService.kt   tangkap layar + loop AI
├── AiClient.kt         panggilan Claude (vision) + parsing keputusan
├── ControlService.kt   AccessibilityService, menyuntik sentuhan
├── Overlay.kt          panel + tombol virtual melayang
└── Prefs.kt            penyimpanan pengaturan & posisi tombol
```
