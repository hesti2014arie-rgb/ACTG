package com.actg.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Satu aksi: tekan tombol [button] (opsional tahan [holdMs]) ATAU swipe [swipe] (UP/DOWN/LEFT/RIGHT). */
data class Press(val button: String?, val holdMs: Long?, val swipe: String? = null)
data class Decision(val presses: List<Press>, val reason: String)

class ApiException(val code: Int, message: String) : IOException("HTTP $code: $message")

/** Mengirim screenshot ke AI (Claude / OpenAI / Gemini) dan menerima keputusan aksi. */
class AiClient(
    private val provider: String,
    private val apiKey: String,
    private val model: String,
) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val json = "application/json".toMediaType()

    private val system = """
        You are an AI player controlling a game on an Android phone. Each turn you receive a screenshot of the
        current screen. The on-screen virtual buttons are overlaid as labeled circles (the label is the button name).
        You can act by pressing those buttons, or by swiping across the screen (finger direction).
        Buttons marked "joystick" move the character: they drag the game's touch thumbstick (the circle labeled
        JOYSTICK) in that direction and KEEP HOLDING it. The character keeps walking until you send another joystick
        direction or the STOP button, so you do not need to repeat a direction every turn. Two joystick buttons at once
        move diagonally. Use STOP only when you really want to stand still.
        Your reply arrives 1-3 seconds after the screenshot was taken, so plan ahead for where things will be.
        A "swipe" rotates the camera (Roblox-style games).
        Reply with ONLY a JSON object, no markdown:
        {"reason":"<max 8 words, Indonesian>","actions":[{"button":"<NAME>","hold_ms":<optional int>},{"swipe":"UP|DOWN|LEFT|RIGHT"}]}
        Use at most 3 actions per turn. Use an empty actions list to wait (e.g. loading screens, cutscenes).
        Only use button names from the provided list.
    """.trimIndent()

    fun decide(
        jpegBase64: String,
        goal: String,
        buttons: List<GameButton>,
        history: List<String>,
        moving: String = "",
    ): Decision {
        val btnText = buttons.joinToString("\n") {
            val kind = if (it.dir.isNotEmpty()) "joystick ${it.dir}" else "tap"
            "- ${it.name} [$kind]: ${it.hint} (default hold ${it.holdMs} ms)"
        }
        val histText = if (history.isEmpty()) "(none)" else history.joinToString("; ")
        val moveText = if (moving.isEmpty()) "standing still" else "WALKING ($moving) - joystick is still held down"
        val userText = "Goal: $goal\n\nAvailable buttons:\n$btnText\n- STOP [control]: release the joystick and stand still\n\n" +
            "Character right now: $moveText\nRecent actions: $histText\n\nChoose the next action."

        val req = when (provider) {
            "openai" -> openAiRequest(jpegBase64, userText)
            "gemini" -> geminiRequest(jpegBase64, userText)
            else -> anthropicRequest(jpegBase64, userText)
        }

        http.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ApiException(resp.code, errorMessage(raw))
            return parse(extractText(raw))
        }
    }

    /** Ambil teks pesan dari body error JSON (format Anthropic/OpenAI/Gemini sama-sama "error.message"). */
    private fun errorMessage(raw: String): String = try {
        val err = JSONObject(raw).opt("error")
        when (err) {
            is JSONObject -> err.optString("message").ifBlank { raw }
            is String -> err
            else -> raw
        }.take(160)
    } catch (e: Exception) {
        raw.take(160)
    }

    // ---------- request per provider ----------

    private fun anthropicRequest(jpeg: String, userText: String): Request {
        val content = JSONArray()
            .put(
                JSONObject().put("type", "image").put(
                    "source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", jpeg)
                )
            )
            .put(JSONObject().put("type", "text").put("text", userText))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 150)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        return Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody(json))
            .build()
    }

    private fun openAiRequest(jpeg: String, userText: String): Request {
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", userText))
            .put(
                JSONObject().put("type", "image_url").put(
                    "image_url", JSONObject().put("url", "data:image/jpeg;base64,$jpeg")
                )
            )
        val body = JSONObject()
            .put("model", model)
            .put("max_completion_tokens", 150)
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", content))
            )
        return Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(body.toString().toRequestBody(json))
            .build()
    }

    private fun geminiRequest(jpeg: String, userText: String): Request {
        val parts = JSONArray()
            .put(
                JSONObject().put(
                    "inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", jpeg)
                )
            )
            .put(JSONObject().put("text", userText))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 150))
        return Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody(json))
            .build()
    }

    // ---------- response ----------

    private fun extractText(raw: String): String {
        val root = JSONObject(raw)
        return when (provider) {
            "openai" -> root.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content")
            "gemini" -> {
                val parts = root.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
            }
            else -> {
                val blocks = root.getJSONArray("content")
                var text = ""
                for (i in 0 until blocks.length()) {
                    val b = blocks.getJSONObject(i)
                    if (b.optString("type") == "text") {
                        text = b.getString("text")
                        break
                    }
                }
                text
            }
        }
    }

    private fun parse(text: String): Decision {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        if (s < 0 || e <= s) throw IOException("Balasan AI bukan JSON: ${text.take(120)}")
        val obj = JSONObject(text.substring(s, e + 1))
        val arr = obj.optJSONArray("actions") ?: JSONArray()
        val presses = (0 until arr.length()).mapNotNull {
            val a = arr.getJSONObject(it)
            val button = a.optString("button", "").ifEmpty { null }
            val swipe = a.optString("swipe", "").ifEmpty { null }
            if (button == null && swipe == null) null
            else Press(button, if (a.has("hold_ms")) a.optLong("hold_ms") else null, swipe)
        }
        return Decision(presses, obj.optString("reason"))
    }
}
